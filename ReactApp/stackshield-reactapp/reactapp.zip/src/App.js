import React, { useState } from 'react';
import { Container, Paper, Typography, Button, Box, CircularProgress } from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import { useLogs } from './hooks/useLogs';
import AlertTable from './components/AlertTable';
import FilterBar from './components/FilterBar';
import ChartDashboard from './components/ChartDashboard';


function App() {

  const [file, setFile] = useState(null);
  const [severityFilter, setSeverityFilter] = useState('');
  const logsMutation = useLogs();
//const data = logsMutation.data?.alerts || [];
  const handleUpload = () => {
    if (file) logsMutation.mutate(file);
  };

  const data = logsMutation.data || [];
  const filtered = severityFilter
    ? data.filter(item => item.alert.severity === severityFilter)
    : data;

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" textAlign="center" gutterBottom>Stack Shield Alerts Dashboard</Typography>

      <Paper sx={{ p: 3, mb: 4 }}>
        <Box display="flex" alignItems="center" gap={2}>
          <Button
            variant="contained"
            component="label"
            startIcon={<UploadFileIcon />}
            size="medium"
          >
            Upload JSON Log
            <input type="file" hidden accept=".json" onChange={e => setFile(e.target.files?.[0])} />
          </Button>

          <Button
            variant="contained"
            color="primary"
            onClick={handleUpload}
            disabled={!file || logsMutation.isLoading}
            size="medium"
          >
            Analyze
          </Button>

          <Button
            onClick={() => setSeverityFilter('')}
            variant="outlined"
            size="medium"
          >
            Clear Filter
          </Button>

          {logsMutation.isLoading && <CircularProgress size={24} />}
        </Box>

        {logsMutation.isError && (
          <Typography color="error" mt={2}>
            Error: {logsMutation.error.message}
          </Typography>
        )}
      </Paper>


      {data.length > 0 && (
        <>
         <ChartDashboard data={filtered} />
          <FilterBar filter={severityFilter} setFilter={setSeverityFilter} />
          <AlertTable alerts={filtered} />

        </>
      )}

    </Container>

  );
}

export default App;
