import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, Box } from '@mui/material';

const severities = ['', 'Critical', 'High', 'Medium', 'Low'];

export default function FilterBar({ filter, setFilter }) {
  return (
    <Box mb={2}>
      <FormControl fullWidth>
        <InputLabel>Filter by Severity</InputLabel>
        <Select
          value={filter}
          label="Filter by Severity"
          onChange={e => setFilter(e.target.value)}
        >
          {severities.map(s => (
            <MenuItem value={s} key={s}>{s || 'All'}</MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}
