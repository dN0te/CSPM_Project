import React from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button
} from '@mui/material';
import { format } from 'date-fns';
import SeverityPill from './SeverityPill';
import * as XLSX from 'xlsx';

export default function AlertTable({ alerts }) {

  const handleDownloadExcel = () => {
    const worksheetData = alerts.map(item => {
      const { alert, log } = item;
      return {
        'Alert ID': alert.id,
        Service: alert.service,
        Resource: alert.resource,
        Time: format(new Date(log.eventTime), 'yyyy-MM-dd HH:mm:ss'),
        Severity: alert.severity,
        Description: alert.description,
        Recommendation: alert.recommendation,
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Alerts');
    XLSX.writeFile(workbook, 'alerts_report.xlsx');
  };

  return (
    <>
      <Button
        variant="contained"
        color="secondary"
        sx={{ mb: 2 }}
        onClick={handleDownloadExcel}
      >
        Download Excel
      </Button>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Alert ID</TableCell>
              <TableCell>Service</TableCell>
              <TableCell>Resource</TableCell>
              <TableCell>Time</TableCell>
              <TableCell>Severity</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Recommendation</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {alerts.map((item, idx) => {
              const { alert, log } = item;
              const time = format(new Date(log.eventTime), 'yyyy-MM-dd HH:mm:ss');
              return (
                <TableRow key={idx}>
                  <TableCell>{alert.id}</TableCell>
                  <TableCell>{alert.service}</TableCell>
                  <TableCell>{alert.resource}</TableCell>
                  <TableCell>{time}</TableCell>
                  <TableCell><SeverityPill severity={alert.severity} /></TableCell>
                  <TableCell>{alert.description}</TableCell>
                  <TableCell>{alert.recommendation}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
