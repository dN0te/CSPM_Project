import React from 'react';
import { Typography, Box } from '@mui/material';
import {
  PieChart, Pie, Cell, Tooltip, BarChart, XAxis, YAxis, Bar, Legend,
  ResponsiveContainer, LineChart, Line
} from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#B370EF'];

const ChartDashboard = ({ data }) => {
  // Pie Chart Data - by Severity
  const severityCounts = data.reduce((acc, item) => {
    const sev = item.alert.severity || '';
    acc[sev] = (acc[sev] || 0) + 1;
    return acc;
  }, {});

  const pieData = Object.keys(severityCounts).map(sev => ({
    name: sev,
    value: severityCounts[sev],
  }));

  // Bar Chart Data - by Source
  const sourceCounts = data.reduce((acc, item) => {
    const src = item.alert.source || '';
    acc[src] = (acc[src] || 0) + 1;
    return acc;
  }, {});

  const barData = Object.keys(sourceCounts).map(src => ({
    source: src,
    count: sourceCounts[src],
  }));

  // Line Chart Data - by Date
  const dateCounts = data.reduce((acc, item) => {
    const raw = item.alert.timestamp;
    const date = raw ? new Date(raw).toISOString().split('T')[0] : '';
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});

  const lineData = Object.keys(dateCounts).sort().map(date => ({
    date,
    count: dateCounts[date],
  }));

  return (
    <>
      <Typography variant="h6" mb={2}>Alert Summary</Typography>
      <Box display="flex" flexWrap="wrap" justifyContent="space-between" gap={2}>
        {/* Pie Chart */}
        <Box flex={1} minWidth={300} height={300}>
          <Typography variant="subtitle1" textAlign="center">By Severity</Typography>
          <ResponsiveContainer width="100%" height="90%">
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={80} label>
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Box>

        {/* Bar Chart */}
        <Box flex={1} minWidth={300} height={300}>
          <Typography variant="subtitle1" textAlign="center">By Source</Typography>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={barData}>
              <XAxis dataKey="source" label={{ value: 'Source', position: 'insideBottom', offset: -5 }} />
              <YAxis allowDecimals={false} label={{ value: 'Count', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </Box>

        {/* Line Chart */}
        <Box flex={1} minWidth={300} height={300}>
          <Typography variant="subtitle1" textAlign="center">Over Time</Typography>
          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={lineData}>
              <XAxis dataKey="date" label={{ value: 'Date', position: 'insideBottom', offset: -5 }} />
              <YAxis allowDecimals={false} label={{ value: 'Alert Count', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="count" stroke="#82ca9d" name="Alerts" />
            </LineChart>
          </ResponsiveContainer>
        </Box>
      </Box>
    </>
  );
};

export default ChartDashboard;
